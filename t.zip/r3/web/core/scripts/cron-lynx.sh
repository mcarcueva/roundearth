#!/bin/sh

/usr/bin/lynx -source http://example.com/cron/YOURKEY > /dev/null 2>&1
